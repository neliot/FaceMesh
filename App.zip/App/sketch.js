/**************************************************
 * University of Sunderland                       *
 **************************************************
 * School of Computer Science and Engineering     *
 **************************************************
 * Script: sketch.js                              *
 * Author: Dr. Evil!                              *
 * Date: 16/01/2024                               *
 **************************************************
 * Description:                                   *
 **************************************************
 * Basic security style application               *
 * to extract faces from a video feed.            *                                   *
 **************************************************/

let video; // Video Feed
let faceMesh; // ML5 Model
let faces = []; // Store Detected Faces
let cnv; // Access Canvas Properties
let dotsCheckbox; // Option Checkbox
let faceCheckbox; // Option Checkbox
let mugshotsCheckbox; // Option Checkbox
let videoCheckbox; // Option Checkbox
let backCheckbox; // Option Checkbox

function preload() {
  faceMesh = ml5.faceMesh({ maxFaces: 5, flipped: true });
}

function windowResized() {
  centerCanvas();
}

function centerCanvas() {
  let x = (windowWidth - width) / 2;
  let y = (windowHeight - height) / 2;
  cnv.position(x, y);
}

function gotFaces(results) {
  faces = results;
}

function setup() {
  cnv = createCanvas(640, 480);
  centerCanvas();
  background(255);
  video = createCapture(VIDEO, { flipped: true });
  video.hide();
  faceMesh.detectStart(video, gotFaces);

  // 1 - Menu (Start)  

  // Menu (End)  
}

// X - Saving Snapshot/Faces (Start)

// Saving Snapshot/Faces (End)

function dots() {
// X - Mesh Dots (Start)

// Mesh Dots (End)
}

function mugs() {
  // X - Mug Shots (Start)

  // Mug Shots (End)
}

function isolateFaces() {
  // X - Isolate Faces (Start)

  // Isolate Faces (End)
}

function back() {
// 3 - Background (End)

// Background (End)
}

function videoFeed() {
  // 2 - Video (Start)  

  // Video (End)
}

function draw() {
  back(); // Manage Background
  videoFeed(); // Video Feed
  isolateFaces(); // Face Isolation 
  dots(); // ML5 Face Mesh KeyPoints
  mugs(); // Mugshot Banner
}
