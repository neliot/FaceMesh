let video; // Video Feed
let faceMesh; // ML5 Model
let faces = []; // Store Detected Faces
let cnv; // Access Canvas Properties
let dotsCheckbox; // Option Checkbox
let faceCheckbox; // Option Checkbox
let mugshotsCheckbox; // Option Checkbox
let videoCheckbox; // Option Checkbox
let backCheckbox; // Option Checkbox

function preload() {
  faceMesh = ml5.faceMesh({ maxFaces: 5, flipped: true });
}

function windowResized() {
  centerCanvas();
}

function centerCanvas() {
  let x = (windowWidth - width) / 2;
  let y = (windowHeight - height) / 2;
  cnv.position(x, y);
}

function setup() {
  cnv = createCanvas(640, 480);
  centerCanvas();
  video = createCapture(VIDEO, { flipped: true });
  video.hide();
  faceMesh.detectStart(video, gotFaces);

  // X - Menu (Start)  
  dotsCheckbox = createCheckbox(' Mesh');
  dotsCheckbox.position(0, 40);
  faceCheckbox = createCheckbox(' Faces');
  faceCheckbox.position(0, 60);
  mugshotsCheckbox = createCheckbox(' Mugshots');
  mugshotsCheckbox.position(0, 80);
  videoCheckbox = createCheckbox(' Video', true);
  videoCheckbox.position(0, 100);
  backCheckbox = createCheckbox(' Background', true);
  backCheckbox.position(0, 120);
  // Menu (End)  
}

// X - Saving Snapshot/Faces (Start)
function saveFaces() {
  if (mugshotsCheckbox.checked()) {
    for (let loop1 = 0; loop1 < faces.length; loop1++) {
      let face = faces[loop1];
      let box = face.box;
      faceImage = video.get(box.xMin, box.yMin, box.width, box.height);
      faceImage.save('face' + loop1, 'png');
    }
  }
}

function saveSnapshot() {
  saveCanvas("canvas.png");
} 

function keyPressed() {
  if (key === 'm') {
    saveFaces();
  }
  if (key === 's') {
    saveSnapshot();
  }
}
// Saving Snapshot/Faces (End)


function gotFaces(results) {
  faces = results;
}

function dots() {
// X - Mesh Dots (Start)
if (dotsCheckbox.checked()) {
    if (faces.length > 0) {
      for (let loop1 = 0; loop1 < faces.length; loop1++) {
        let face = faces[loop1];
        for (let loop2 = 0; loop2 < face.keypoints.length; loop2++) {
          noStroke();
          fill(0, 255, 0);
          circle(face.keypoints[loop2].x, face.keypoints[loop2].y, 3);
        }
      }
    }
  }
// Mesh Dots (End)
}

function mugs() {
// X - Mug Shots (Start)
if (mugshotsCheckbox.checked()) {
    strokeWeight(6);
    stroke(125, 125, 125);
    fill(255)
    rect(3, 3, 634, 145, 5);
    for (let loop1 = 0; loop1 < faces.length; loop1++) {
      let face = faces[loop1];
      let box = face.box;
      let faceImage = video.get(box.xMin, box.yMin, box.width, box.height);
      faceImage.resize(80, 100);
      textSize(18);
      image(faceImage, (loop1 * 85) + 10, 10);
      text("face " + loop1, (loop1 * 85) + 25, 130);
    }
  }
// Mug Shots (End)
}

function isolateFaces() {
// X - Isolate Faces (Start)
if (faceCheckbox.checked()) {
    if (faces.length > 0) {
      let frame;
      let face;
      let box;
      let faceImage;
      for (let loop1 = 0; loop1 < faces.length; loop1++) {
        frame = video.get(0, 0, width, height);
        face = faces[loop1];
        box = face.box;
        shape = createGraphics(width, height);
        shape.fill(0);
        shape.strokeWeight(5);
        shape.beginShape();
        for (let points = 0; points < face.faceOval.keypoints.length; points++) {
          shape.point(face.faceOval.keypoints[points].x, face.faceOval.keypoints[points].y);
          shape.curveVertex(face.faceOval.keypoints[points].x, face.faceOval.keypoints[points].y);
        }
        shape.endShape(CLOSE);
        frame.mask(shape);
        let faceImage = frame.get(box.xMin, box.yMin, box.width, box.height);
        image(faceImage, box.xMin, box.yMin);
      }
    }
  }
// Isolate Faces (End)
}

function back(){
// X - Background (End)
if (backCheckbox.checked()) {
    background(0);
  }
// Background (End)
}

function videoFeed(){
// X - Video (Start)  
  if (videoCheckbox.checked()) {
    image(video, 0, 0);
  }
// Video (End)
}

function draw() {
  back();
  videoFeed();
  isolateFaces();
  dots();
  mugs();
}
